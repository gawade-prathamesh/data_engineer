## [Main title](../README.md)
### [Interview questions](full.md)

### Will be available soon